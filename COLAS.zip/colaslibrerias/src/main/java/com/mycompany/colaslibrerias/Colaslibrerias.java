/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.colaslibrerias;

/**
 *
 * @author ESTUDIANTES
 */
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Deque;
import java.util.PriorityQueue;
public class Colaslibrerias {

    public static void main(String[] args) {
        System.out.println("ejercicios colas con librerias de JAVA/n");
        colasimple();
        colasCirculares();
        ColasPrioridad();
    }
    static void colasimple(){
     System.out.println("ejercicios colas simples");
     Queue<String> java = new ArrayDeque<>();
     java.offer("ANA");
     java.offer("vivian");
     java.offer("leiner");
     System.out.println("java : " + java.poll() + "," + java.poll() + "/n");
}
    static void colasCirculares() {

             Queue<String> java = new ArrayDeque<>();
              java.offer("Ana");
              java.offer("vivian");
java.offer("leiner");
java.offer("sale : " + java.poll ());
java.offer("fabio");
 System.out.println("java: " + java.poll() + "," + java.poll () + "/n");

    }
static void ColasPrioridad(){
    Queue<Integer>java = new PriorityQueue<>();
      java.offer(5);
  java.offer(2);
  java.offer(3);
  System.out.println("java: " + java.poll() + "," + java.poll () + "n/");
  
}

 static void ColasDoble(){
     System.out.println("Coladoble (deque): permite usar ambos extremos ");
     
     Deque<String> java= new ArrayDeque<>();
      java.offer("ANA");
     java.offer("vivian");
     java.offerFirst("leiner");
      System.out.println("java : sale del inicio " + java.pollFirst() +  "sale del final" + java.pollLast() + "/n");
 }

}
