package com.mycompany.parcial_1;

import java.util.Scanner;

public class PARCIAL_1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Producto[] inventario = new Producto[10];
        int cantidadRegistrados = 0;
        int opcion;

        do {
            System.out.println("\n=================================");
            System.out.println("            INVENTARIO ");
            System.out.println("=================================");
            System.out.println("1. Registrar producto ");
            System.out.println("2. Mostrar productos ");
            System.out.println("3. Buscar producto secuencialmente ");
            System.out.println("4. Busqueda binaria recursiva ");
            System.out.println("5. Ordenar por precio ");
            System.out.println("6. Ordenar por cantidad ");
            System.out.println("7. Ordenar por nombre ");
            System.out.println("8. Calcular valor total ");
            System.out.println("9. Contar por categoría ");
            System.out.println("10. Mostrar producto más costoso");
            System.out.println("0. Salir");
            System.out.print("\nSeleccione una opción: ");

            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    if (cantidadRegistrados < 10) {
                        System.out.println("++ Registrar nuevo producto ++");
                        System.out.print("-Ingrese código: ");
                        int codigo = scanner.nextInt();
                        scanner.nextLine();

                        System.out.print("-Ingrese nombre: ");
                        String nombre = scanner.nextLine();

                        System.out.print("-Ingrese categoría: ");
                        String categoria = scanner.nextLine();

                        System.out.print("-Ingrese precio: ");
                        double precio = scanner.nextDouble();

                        System.out.print("-Ingrese cantidad: ");
                        int cantidad = scanner.nextInt();

                        inventario[cantidadRegistrados] = new Producto(codigo, nombre, categoria, precio, cantidad);
                        cantidadRegistrados++;
                        System.out.println("---------------------------------");
                        System.out.println("¡Producto registrado con éxito!");
                    } else {
                        System.out.println("-------------------------------------------------");
                        System.out.println("El inventario está lleno. No se puede registrar el producto.");
                    }
                    break;

                case 2:
                    System.out.println("-------------------------------------------------");
                    System.out.println("++ LISTA DE PRODUCTOS REGISTRADOS ++");
                    if (cantidadRegistrados == 0) {
                         System.out.println("-------------------------------------------------");
                        System.out.println("No hay productos registrados en el inventario!!!!");
                    } else {
                        mostrarProductos(inventario, 0);
                    }
                    break;

                case 3:
                     System.out.println("--------------------------");
                    System.out.println("++ BÚSQUEDA SECUENCIAL ++");
                    if (cantidadRegistrados == 0) {
                         System.out.println("-------------------------");
                        System.out.println("El inventario está vacío.");
                    } else {
                        System.out.print("Ingrese el código del producto: ");
                        int codigoBuscado = scanner.nextInt();
                        scanner.nextLine();

                        Producto resultado = buscarSecuencial(inventario, cantidadRegistrados, codigoBuscado);

                        if (resultado != null) {
                            System.out.println("--------------------------");
                            System.out.println("¡Producto encontrado!");
                            System.out.println(resultado);
                        } else {
                            System.out.println("-----------------------------------------------------------------");
                            System.out.println("No se encontró ningún producto con el código: " + codigoBuscado);
                        }
                    }
                    break;

                case 4:
                    System.out.println("----------------------------------");
                    System.out.println("++ BÚSQUEDA BINARIA RECURSIVA ++");
                    if (cantidadRegistrados == 0) {
                        System.out.println("--------------------------");
                        System.out.println("El inventario está vacío.");
                    } else {
                        System.out.print("Ingrese el código del producto a buscar: ");
                        int codigoBuscado = scanner.nextInt();
                        scanner.nextLine();

                        Producto resultado = buscarBinariaRecursiva(inventario, 0, cantidadRegistrados - 1, codigoBuscado);

                        if (resultado != null) {
                            System.out.println("¡Producto encontrado!");
                            System.out.println(resultado);
                        } else {
                            System.out.println("No se encontró ningún producto con el código: " + codigoBuscado);
                        }
                    }
                    break;

                case 5:
                    System.out.println("++ ORDENAR POR PRECIO (BUBBLE SORT OPTIMIZADO) ++");
                    if (cantidadRegistrados < 2) {
                        System.out.println("Se necesitan al menos 2 productos registrados para ordenar.");
                    } else {
                        ordenarPorPrecioBubbleSort(inventario, cantidadRegistrados);
                        System.out.println("¡Productos ordenados por precio!");
                        mostrarProductos(inventario, 0);
                    }
                    break;

                case 6:
                    System.out.println("++ ORDENAR POR CANTIDAD (SELECTION SORT) ++");
                    if (cantidadRegistrados < 2) {
                        System.out.println("Se necesitan al menos 2 productos registrados para ordenar.");
                    } else {
                        ordenarPorCantidadSelectionSort(inventario, cantidadRegistrados);
                        System.out.println("¡Productos ordenados por cantidad!");
                        mostrarProductos(inventario, 0);
                    }
                    break;

                case 7:
                    System.out.println("++ ORDENAR POR NOMBRE (INSERTION SORT) ++");
                    if (cantidadRegistrados < 2) {
                        System.out.println("------------------------------------------------------------");
                        System.out.println("Se necesitan al menos 2 productos registrados para ordenar.");
                    } else {
                        ordenarPorNombreInsertionSort(inventario, cantidadRegistrados);
                        System.out.println("¡Productos ordenados alfabéticamente por nombre!");
                        mostrarProductos(inventario, 0);
                    }
                    break;

                case 8:
                    System.out.println("++ VALOR TOTAL DEL INVENTARIO (RECURSIVO) ++");
                    if (cantidadRegistrados == 0) {
                        System.out.println("El inventario está vacío.");
                    } else {
                        double total = calcularValorTotalRecursivo(inventario, cantidadRegistrados - 1);
                        System.out.printf("El valor total acumulado del inventario es: $%.2f\n", total);
                    }
                    break;

                case 9:
                    System.out.println("++ CONTAR PRODUCTOS POR CATEGORÍA (RECURSIVO) ++");
                    if (cantidadRegistrados == 0) {
                        System.out.println("El inventario está vacío.");
                    } else {
                        System.out.print("Ingrese la categoría: ");
                        String catBuscada = scanner.nextLine();

                        int totalCategoria = contarPorCategoriaRecursivo(inventario, cantidadRegistrados - 1, catBuscada);
                        System.out.println("Total de productos en '" + catBuscada + "': " + totalCategoria);
                    }
                    break;

                case 10:
                    System.out.println("++ PRODUCTO MÁS COSTOSO ++");
                    if (cantidadRegistrados == 0) {
                        System.out.println("El inventario está vacío.");
                    } else {
                        Producto costoso = obtenerProductoMasCostoso(inventario, cantidadRegistrados);
                        System.out.println(costoso);
                    }
                    break;

                case 0:
                    System.out.println("--------------------------");
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("--------------------");
                    System.out.println("Opción inválida.");
                    break;
            }
        } while (opcion != 0);

        scanner.close();
    }

    
    public static void mostrarProductos(Producto[] productos, int posicion) {
        if (posicion >= productos.length || productos[posicion] == null) {
            return;
        }
        System.out.println((posicion + 1) + ". " + productos[posicion]);
        mostrarProductos(productos, posicion + 1);
    }

   
    public static Producto buscarSecuencial(Producto[] inventario, int cantidadRegistrados, int codigoBuscado) {
        for (int i = 0; i < cantidadRegistrados; i++) {
            if (inventario[i].getCodigo() == codigoBuscado) {
                return inventario[i];
            }
        }
        return null;
    }

   
    public static Producto buscarBinariaRecursiva(Producto[] inventario, int inicio, int fin, int codigoBuscado) {
        if (inicio > fin) {
            return null;
        }
        int medio = inicio + (fin - inicio) / 2;

        if (inventario[medio].getCodigo() == codigoBuscado) {
            return inventario[medio];
        }
        if (inventario[medio].getCodigo() < codigoBuscado) {
            return buscarBinariaRecursiva(inventario, medio + 1, fin, codigoBuscado);
        } else {
            return buscarBinariaRecursiva(inventario, inicio, medio - 1, codigoBuscado);
        }
    }

    
    public static void ordenarPorPrecioBubbleSort(Producto[] inventario, int cantidadRegistrados) {
        boolean intercambiado;
        for (int i = 0; i < cantidadRegistrados - 1; i++) {
            intercambiado = false;
            for (int j = 0; j < cantidadRegistrados - i - 1; j++) {
                if (inventario[j].getPrecio() > inventario[j + 1].getPrecio()) {
                    Producto aux = inventario[j];
                    inventario[j] = inventario[j + 1];
                    inventario[j + 1] = aux;
                    intercambiado = true;
                }
            }
            if (!intercambiado) break; 
        }
    }

   
    public static void ordenarPorCantidadSelectionSort(Producto[] inventario, int cantidadRegistrados) {
        for (int i = 0; i < cantidadRegistrados - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < cantidadRegistrados; j++) {
                if (inventario[j].getCantidad() < inventario[minIndex].getCantidad()) {
                    minIndex = j;
                }
            }
            if (minIndex != i) {
                Producto aux = inventario[i];
                inventario[i] = inventario[minIndex];
                inventario[minIndex] = aux;
            }
        }
    }

    
    public static void ordenarPorNombreInsertionSort(Producto[] inventario, int cantidadRegistrados) {
        for (int i = 1; i < cantidadRegistrados; i++) {
            Producto clave = inventario[i];
            int j = i - 1;

            while (j >= 0 && inventario[j].getNombre().compareToIgnoreCase(clave.getNombre()) > 0) {
                inventario[j + 1] = inventario[j];
                j--;
            }
            inventario[j + 1] = clave;
        }
    }

  
    public static double calcularValorTotalRecursivo(Producto[] inventario, int posicion) {
        if (posicion < 0 || inventario[posicion] == null) {
            return 0;
        }
        return (inventario[posicion].getPrecio() * inventario[posicion].getCantidad()) 
               + calcularValorTotalRecursivo(inventario, posicion - 1);
    }

    
    public static int contarPorCategoriaRecursivo(Producto[] inventario, int posicion, String categoriaBuscada) {
        if (posicion < 0 || inventario[posicion] == null) {
            return 0;
        }
        int coincide = inventario[posicion].getCategoria().equalsIgnoreCase(categoriaBuscada) ? 1 : 0;
        return coincide + contarPorCategoriaRecursivo(inventario, posicion - 1, categoriaBuscada);
    }

   
    public static Producto obtenerProductoMasCostoso(Producto[] inventario, int cantidadRegistrados) {
        Producto masCostoso = inventario[0];
        for (int i = 1; i < cantidadRegistrados; i++) {
            if (inventario[i].getPrecio() > masCostoso.getPrecio()) {
                masCostoso = inventario[i];
            }
        }
        return masCostoso;
    }
}

class Producto {
    private int codigo;
    private String nombre;
    private String categoria;
    private double precio;
    private int cantidad;

    public Producto(int codigo, String nombre, String categoria, double precio, int cantidad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public int getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public String getCategoria() { return categoria; }
    public double getPrecio() { return precio; }
    public int getCantidad() { return cantidad; }

    @Override
    public String toString() {
        return "Código: " + codigo + " | Nombre: " + nombre + " | Categoría: " + categoria + 
               " | Precio: $" + precio + " | Cantidad: " + cantidad;
    }
}

       
     
        
    
      



   
    
   
    
