


import java.util.Scanner;

public class Gestor_producto_cruz {


static String[] nombres = new String[5];
static double[] precios = new double[5];
static int contador = 0;

public static void main(String[] args) {

    Scanner sc = new Scanner(System.in);
    int rol;

    do {
        System.out.println("\n--- SISTEMA DE PRODUCTOS ---");
        System.out.println("Seleccione su tipo de usuario:");
        System.out.println("1. Usuario normal");
        System.out.println("2. Administrador");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");

        rol = sc.nextInt();
        sc.nextLine();

        switch (rol) {

            case 1 -> {
               
                int opcionUsuario;

                do {
                    System.out.println("\n--- MENÚ USUARIO ---");
                    System.out.println("1. Listar productos");
                    System.out.println("2. Buscar producto");
                    System.out.println("0. Salir");
                    System.out.print("Seleccione una opción: ");

                    opcionUsuario = sc.nextInt();
                    sc.nextLine();

                    switch (opcionUsuario) {

                        case 1 -> {
                            Listar();
                        }

                        case 2 -> {
                            System.out.println("Nombre del producto a buscar: ");
                            String nombre = sc.nextLine();

                            int posicion = buscar(nombre);

                            if (posicion == -1) {
                                System.out.println("Producto no encontrado.");
                            } else {
                                System.out.println("Producto encontrado:");
                                System.out.println(
                                        nombres[posicion] + " - $ " + precios[posicion]
                                );
                            }
                        }

                        case 0 -> {
                            System.out.println("Saliendo del menú de usuario...");
                        }

                        default -> {
                            System.out.println("Opción inválida.");
                        }
                    }

                } while (opcionUsuario != 0);
            }

            case 2 -> {
                
                int opcionAdmin;

                do {
                    System.out.println("\n--- MENÚ ADMINISTRADOR ---");
                    System.out.println("1. Agregar producto");
                    System.out.println("2. Listar productos");
                    System.out.println("3. Buscar producto");
                    System.out.println("4. Actualizar precio");
                    System.out.println("5. Eliminar producto");
                    System.out.println("0. Salir");
                    System.out.print("Seleccione una opción: ");

                    opcionAdmin = sc.nextInt();
                    sc.nextLine();

                    switch (opcionAdmin) {

                        case 1 -> {
                            System.out.println("Nombre del producto: ");
                            String nombre = sc.nextLine();

                            System.out.println("Precio del producto: ");
                            double precio = sc.nextDouble();
                            sc.nextLine();

                            agregar(nombre, precio);
                        }

                        case 2 -> {
                            Listar();
                        }

                        case 3 -> {
                            System.out.println("Nombre del producto a buscar: ");
                            String nombre = sc.nextLine();

                            int posicion = buscar(nombre);

                            if (posicion == -1) {
                                System.out.println("Producto no encontrado.");
                            } else {
                                System.out.println(
                                        "Producto encontrado en la posición "
                                        + posicion
                                );
                                System.out.println(
                                        nombres[posicion] + " - $ "
                                        + precios[posicion]
                                );
                            }
                        }

                        case 4 -> {
                            System.out.println("Nombre del producto a actualizar: ");
                            String nombre = sc.nextLine();

                            System.out.println("Nuevo precio: ");
                            double nuevoPrecio = sc.nextDouble();
                            sc.nextLine();

                            actualizarPrecio(nombre, nuevoPrecio);
                        }

                        case 5 -> {
                            System.out.println("Nombre del producto a eliminar: ");
                            String nombre = sc.nextLine();

                            eliminar(nombre);
                        }

                        case 0 -> {
                            System.out.println("Saliendo del menú de administrador...");
                        }

                        default -> {
                            System.out.println("Opción inválida.");
                        }
                    }

                } while (opcionAdmin != 0);
            }

            case 0 -> {
                System.out.println("Saliendo del sistema...");
            }

            default -> {
                System.out.println("Opción inválida.");
            }
        }

    } while (rol != 0);

    sc.close();
}

static boolean agregar(String nombre, double precio) {

    if (contador >= nombres.length) {
        System.out.println("No hay espacio en el vector para almacenar.");
        return false;
    }

    nombres[contador] = nombre;
    precios[contador] = precio;
    contador++;

    System.out.println("Producto agregado correctamente.");

    return true;
}


static void Listar() {

    if (contador == 0) {
        System.out.println("No hay productos registrados.");
        return;
    }

    System.out.println("\n--- LISTA DE PRODUCTOS ---");

    for (int i = 0; i < contador; i++) {
        System.out.println(
                i + " - " + nombres[i] + " - $ " + precios[i]
        );
    }
}


static int buscar(String nombre) {

    for (int i = 0; i < contador; i++) {

        if (nombres[i].equalsIgnoreCase(nombre)) {
            return i;
        }
    }

    return -1;
}

// ACTUALIZAR
static boolean actualizarPrecio(String nombre, double nuevoPrecio) {

    int posicion = buscar(nombre);

    if (posicion == -1) {
        System.out.println("Producto no encontrado.");
        return false;
    }

    precios[posicion] = nuevoPrecio;

    System.out.println("Precio actualizado correctamente.");

    return true;
}


static boolean eliminar(String nombre) {

    int posicion = buscar(nombre);

    if (posicion == -1) {
        System.out.println("Producto no encontrado.");
        return false;
    }

    for (int i = posicion; i < contador - 1; i++) {
        nombres[i] = nombres[i + 1];
        precios[i] = precios[i + 1];
    }

    nombres[contador - 1] = null;
    precios[contador - 1] = 0;

    contador--;

    System.out.println("Producto eliminado correctamente.");

    return true;
}


}
